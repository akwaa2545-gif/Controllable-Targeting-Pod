# Observer 0.5.7 + Targeting Pod Display 0.1.17

Separate mods, matched release. Close Nuclear Option, back up both DLLs/configs and replace Observer.dll and TargetingPodDisplay.dll once each under BepInEx/plugins. Do not install duplicates or copy example configs over your settings. Confirm both version numbers in the next startup log.

## Fullscreen can continue without Auto Hold

Auto Hold refusing to engage or releasing no longer forces missile fullscreen to close. Its safety limits are unchanged. A persistent, high-contrast AUTO HOLD INACTIVE / AIRCRAFT NOT STABILIZED warning tells you to exit fullscreen to fly. This is not continued stabilization or pilot control while watching. Deliberate manual override and genuine camera/input/context failures still exit fullscreen. Detailed reasons now include the measured safety value and required limit where available.

## Mouse-free watched views, keyboard takeover

With Auto Hold enabled, map and paired TGP fullscreen ignore the normal virtual-stick mouse movement while keyboard/controller steering remains usable and cancels Hold. Those views stay open on keyboard takeover. Missile fullscreen ignores virtual-stick mouse steering regardless of Hold, and keyboard/controller takeover returns to normal flight view. Camera/map mouse controls remain available. Auto Hold off preserves native map/TGP behavior. Enabled direct Mouse Pitch/Roll/Yaw bindings are unsupported and explicitly refuse/close safely; this release never rewrites your bindings. See the release guide for supported setup and live checks.

## Initialization hotfix

The settings menu now waits for its new canvas to become raycast-ready before opening. Its shield uses a nonzero byte alpha and cannot be discarded as a fully transparent mesh. Native context loss, competing raycasts and readiness timeout still keep the panel closed. See the release guide for diagnosis and live retest steps.

## Shared in-game settings

In a supported offline cockpit, pause with Esc, then press your Observer Panel binding (default F8). The Observer-hosted menu has Observer and TGP sections with settings and an ACTION / ASSIGNED KEYS list. Select an action to edit it. It remains accessible with Observer viewing disabled. ConfigurationManager is optional; TGP by itself still uses its config or ConfigurationManager.

The binding editor offers Key only or a special input such as Left click, Right click, Ctrl, Shift or Alt. Choose Alone or Combine. Combine then captures an ordinary keyboard key. Clear unbinds; Cancel preserves the previous value. Saved combinations and recognized overlaps are visible. This is an original Arma-inspired workflow, not a replica or an integration with Arma.

Mouse0–6 are supported when Unity receives them; extra mouse buttons depend on hardware/OS mapping. Discrete special-alone actions use clean release gestures. A chord or context change cancels that tap. Special-alone continuous TGP controls require a fresh eligible press. Mouse-alone Observer actions and mouse-related menu requests wait for release; TGP mouse toggles also wait for native Select. Observer mouse-plus-keyboard view shortcuts activate on the keyboard edge while the mouse button is held. MapWatch still needs an actual left-click on a missile: hold its configured input then click. Plain left-click alone is not a MapWatch binding.

Known overlaps show warnings rather than being silently rejected. Native/other-mod input is not globally suppressed: a shared click can also fire, pan, select or open a map order menu. Unknown/unreadable conflict state, unsupported keys and unsafe view contexts still refuse. Rebind while paused. Escape remains cancellation; controller axes, wheel bindings, Windows/Command/AltGr and OS-intercepted inputs are not added.

Existing settings remain. TGP keeps its original main-key entries and adds companion modifier strings; an existing raw config is backed up once before binding it. Do not delete or replace your config to update. If you clear the Panel binding, use ConfigurationManager or close the game and restore `Keys.Panel = F8` in `BepInEx/config/io.github.nuclearoption.observer.cfg`.

Observer retains direct main-display fullscreen, missile PiP, MapWatch and opt-in Flight Hold. TGP retains Scan/Follow, aircraft-relative rear gimbal stop, ground stabilization, IR, indicators, PiP and cockpit options. Wider viewing from extra targeting-pod equipment still awaits verified equipment identity. No live game, hardware or GPU validation was performed here.

See [release guide](docs/OBSERVER_0.5.7_RELEASE.md), [paired smoke checklist](docs/OBSERVER_0.5.7_SMOKE_TEST.md) and [TGP guide](docs/TARGETING_POD_DISPLAY.md).

## Build source

Supply your own game Managed and BepInEx core references with SDK 10.0.403. Only authored source/tests/docs/config are included, not proprietary or loader/compiler binaries. Build each product with `-p:GameRefs=/your/Managed -p:LoaderRefs=/your/BepInEx/core`. Run executable tests with `dotnet run --project tests/<suite> -c Release` and Python unittest discovery. Some adapter/persistence suites also need the reference overrides.
